import { Box } from "@mui/system";
import type React from "react";
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, useTheme } from "@mui/material";
import { useBuildTable } from "../../../../hooks/useMainBuildInfo";
import type { MainBranchBuildInfo } from "../../../../helper/interfaces";
import { convertDateToMinAndSec } from "../../../../helper/format";
import CustomSkeleton from "../../../../components/loader/customSkeleton";
import { StatusIndicator } from "../../../../components/statusIndicator";


const LeftSectionLower: React.FC = () => {
    const theme = useTheme()
    const { data: rows, isLoading } = useBuildTable()

    if (isLoading) {
        return <CustomSkeleton />
    }

    return (
        <Box
            sx={{
                backgroundColor: theme.palette.background.paper,
                // borderRadius: 3,
                p: 1,
                color: "white",
                height: "100%"
            }}
        >
            <Typography variant="h6" sx={{ mb: 2 }}>
                All Branch Build Runs
            </Typography>

            <TableContainer
                component={Paper}
                sx={{
                    maxHeight: "25dvh",
                    backgroundColor: theme.palette.background.paper,

                    "&::-webkit-scrollbar": {
                        width: 8,
                    },

                    "&::-webkit-scrollbar-track": {
                        background: theme.palette.background.default,
                        borderRadius: 8,
                    },

                    "&::-webkit-scrollbar-thumb": {
                        background: theme.palette.primary.main,
                        borderRadius: 8,
                    },

                    "&::-webkit-scrollbar-thumb:hover": {
                        background: theme.palette.primary.dark,
                    },

                    // Firefox
                    scrollbarWidth: "thin",
                    scrollbarColor: `${theme.palette.primary.main} ${theme.palette.background.default}`,

                }}
            >
                <Table stickyHeader size="small">
                    {/* Header */}
                    <TableHead>
                        <TableRow>
                            {["State", "Build Number", "Build Run State", "Run Duration", "Pipeline Name"].map((head) => (
                                <TableCell
                                    key={head}
                                    sx={{
                                        backgroundColor: theme.palette.background.default,
                                        fontWeight: theme.typography.h5.fontWeight
                                    }}
                                >
                                    {head}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {rows.map((row: MainBranchBuildInfo) => (
                            <TableRow
                                key={row.id}
                                hover
                                sx={{
                                    "&:hover": {
                                        backgroundColor: theme.palette.primary.main
                                    }
                                }}>
                                <TableCell>
                                    <StatusIndicator
                                        state={row.state}
                                    />
                                </TableCell>

                                <TableCell
                                    sx={{
                                        color: "60a5fa",
                                        cursor: "pointer",
                                        "&:hover": { textDecoration: "underline" }
                                    }}
                                >{row.run_number}</TableCell>

                                <TableCell sx={{ color: "#cbd5f5" }}>{row.state}</TableCell>

                                <TableCell sx={{ color: "#94a3b8" }}>{convertDateToMinAndSec(row.duration)}</TableCell>

                                <TableCell sx={{ color: "cbd5f5" }}>{row.pipeline}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Box>
    )
}

export default LeftSectionLower