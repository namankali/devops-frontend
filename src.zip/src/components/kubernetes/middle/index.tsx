import { Grid } from "@mui/system"
import ResourcesSidebar from "./resourcesSideBar"

const MiddleKubernetesSection: React.FC = () => {
    return (
        <Grid
            container spacing={2} sx={{ mb: 2 }}
        >
            <Grid size={{ xs: 12, lg: 3 }}>
                <ResourcesSidebar />
            </Grid>
            <Grid size={{ xs: 12, lg: 5 }}>Second One</Grid>
            <Grid size={{ xs: 12, lg: 4 }}>Third One</Grid>
        </Grid>
    )
}

export default MiddleKubernetesSection