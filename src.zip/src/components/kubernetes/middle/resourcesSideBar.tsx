import { Card, CardContent, List, ListItemButton, Typography } from "@mui/material"


const ResourcesSidebar: React.FC = () => {
    return (
        <Card sx={{ height: "100%" }}>
            <CardContent>
                <Typography>Resources</Typography>
                <List>
                    <ListItemButton selected>Pods</ListItemButton>
                    <ListItemButton selected>Deployments</ListItemButton>
                    <ListItemButton selected>ReplicaSets</ListItemButton>
                    <ListItemButton selected>DeamonSets</ListItemButton>
                    <ListItemButton selected>Jobs</ListItemButton>
                    <ListItemButton selected>CronJobs</ListItemButton>
                    <ListItemButton selected>Services</ListItemButton>
                    <ListItemButton selected>Ingress</ListItemButton>
                    <ListItemButton selected>ConfigMaps</ListItemButton>
                    <ListItemButton selected>Secrets</ListItemButton>
                    <ListItemButton selected>Persistant Volumes</ListItemButton>
                    <ListItemButton selected>Namespaces</ListItemButton>
                </List>
            </CardContent>
        </Card>
    )
}

export default ResourcesSidebar