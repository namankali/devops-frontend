import { create } from "zustand"

type Resources = | "pods" | "deployments" | "services" | "jobs" | "replicaSets" | "statefulSets" | "deomanSets" | "cronJobs" | "jobs" | "ingress" | "configMaps" | "secrets" | "persistantVolumes" | "namespaces"

interface KubernetesStore {
    selectedResource: Resources;
    setSelectedResource: (resources: Resources) => void
}

export const KubernetesStore = create<KubernetesStore>((set) => ({
    selectedResource: "pods",
    setSelectedResource: (resource) => set({ selectedResource: resource })
}))