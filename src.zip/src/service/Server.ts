import axios from "axios";
import Cookies from "js-cookie";
import Toast from "../utils/toast";
import type { Login_in } from "../utils/types";
import type { ApiResponse, BuildChart, BuildRun, LoginResponse, PipelineStats } from "../helper/types";
import type { MainBranchBuildInfo, StartConvo } from "../helper/interfaces";

export default class Server {
    // static BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:3001"
    static BASE_URL = ""
    static onLogout: (() => void) | null = null;
    static refreshPromise: Promise<any> | null = null

    static setLogoutCallback(callback: any) {
        this.onLogout = callback;
    }


    static async makeRequest<T = unknown>(
        method: string,
        endpoint: string,
        data: { [key: string]: any } = {},
        params: Record<string, any> = {},
        hasRetried: boolean = false
    ): Promise<T> {
        try {
            console.log("API Call =>>", endpoint, new Date().toString());
            const access_token = Cookies.get("x-access-token")

            const response = await axios({
                method,
                url: `${this.BASE_URL}${endpoint}`,
                data,
                params,
                headers: {
                    ...(data instanceof FormData ? {} : { "Content-Type": "application/json" }),
                    "x-access-token": access_token || ""
                },
                withCredentials: true
            })

            return response.data
        } catch (error: any) {
            if (!error.response) {
                Toast.error("Backend server is not reachable")
                throw error
            }

            const status = error.response.status;
            const message = error?.response?.data?.message.toLowerCase() || ""

            const isRefreshing = endpoint === "/users/refresh"

            if (status === 401 && !isRefreshing && !hasRetried && (
                message?.includes("token expired") || message?.includes("token verification failed")
            )) {
                try {
                    if (!this.refreshPromise) {
                        this.refreshPromise = axios.post(
                            `${this.BASE_URL}/users/refresh`,
                            {},
                            { withCredentials: true }
                        );
                    }

                    await this.refreshPromise;
                    this.refreshPromise = null

                    return this.makeRequest(
                        method,
                        endpoint,
                        data,
                        params,
                        true
                    );

                } catch (refreshError) {
                    this.refreshPromise = null;

                    Cookies.remove("x-access-token");
                    Cookies.remove("refresh-token");

                    if (typeof this.onLogout === "function") {
                        this.onLogout();
                    }

                    throw refreshError;
                }
            }
            throw error.response?.data || {
                message: "Something went wrong",
                status: 500,
            };
        }
    }

    // Users
    static async signin(obj: Login_in): Promise<LoginResponse> {
        return this.makeRequest<LoginResponse>(
            "post",
            "/api/users/v1/login",
            obj
        );
    }


    // events
    static async get_build_count(): Promise<ApiResponse<PipelineStats>> {
        return this.makeRequest<ApiResponse<PipelineStats>>(
            "get",
            "/api/actions/v1/pipeline"
        );
    }
    static async buildRunInfo(): Promise<ApiResponse<BuildRun[]>> {
        return this.makeRequest<ApiResponse<BuildRun[]>>(
            "get",
            "/api/actions/v1/info/build"
        );
    }

    static async mainBuildBuildInfo(): Promise<ApiResponse<MainBranchBuildInfo[]>> {
        return this.makeRequest<ApiResponse<MainBranchBuildInfo[]>>(
            "get",
            "/api/actions/v1/info/main"
        );
    }


    static async buildDurationChart(): Promise<ApiResponse<BuildChart[]>> {
        return this.makeRequest<ApiResponse<BuildChart[]>>(
            "get",
            "/api/actions/v1/build/chart"
        );
    }

    // Chats

    static async chats(
        limit: number = 10,
        offset: number = 0
    ): Promise<ApiResponse<any>> {
        return this.makeRequest<ApiResponse<any>>(
            "get",
            "/api/chats/v1/stream",
            {},
            {
                limit: limit,
                offset: offset
            }
        );
    }

    // Start conversation
    static async start_convo(obj: StartConvo): Promise<any> {
        return this.makeRequest<any>(
            "post",
            "/api/chats/v1/chat",
            obj
        )
    }

    // insert message in convsersation
    static async new_chat(obj: any): Promise<any> {
        return this.makeRequest<any>(
            "patch",
            "/api/chats/v1/new/message",
            obj
        );
    }


    // Dashboard
    static async dashboard_repo_details_count(): Promise<any> {
        return this.makeRequest<any>(
            "get",
            "/api/actions/v1/dashboard/rd"
        );
    }

    static async dashboard_repo_details(): Promise<any> {
        return this.makeRequest<any>(
            "get",
            "/api/actions/v1/dashboard/repos"
        );
    }

    // Kubernetes
    static async kubernetesInfo(namespace = "default"): Promise<any> {
        return this.makeRequest<any>(
            "get",
            `/api/kubernetes/v1/info/${namespace}`,
            {},
            {
                "pods": "true",
                "deployments": "true",
                "nodes": "true",
                "services": "true",
                "clusters": "true",
            }
        )
    }

    static async namespacesInfo(): Promise<any>{
        return this.makeRequest<any>(
            "get",
            "/api/kubernetes/v1/ns",
        )
    }
}